/**
 * Fetch products.json from a Shopify-like store and optionally search/filter results.
 *
 * Notes:
 * - Many storefronts expose products at https://STORE_DOMAIN/products.json
 * - CORS: When calling from a browser, the remote store must allow cross-origin requests.
 * - This helper fetches the first page by default and can accept `limit` and `page` query params.
 *
 * Usage:
 * import { searchItems } from './requests/search_items';
 * await searchItems({ storeDomain: 'https://gymshark.com', query: 'shirt', limit: 20 });
 */

const DEFAULT_TIMEOUT = 8000;

function buildUrl(storeDomain, { limit, page } = {}) {
	const url = new URL('/products.json', storeDomain);
	if (limit) url.searchParams.set('limit', String(limit));
	if (page) url.searchParams.set('page', String(page));
	return url.toString();
}

function timeoutFetch(resource, options = {}) {
	const { timeout = DEFAULT_TIMEOUT } = options;
	if (typeof AbortController === 'undefined') {
		// In environments without AbortController, fallback to plain fetch
		return fetch(resource, options);
	}

	const controller = new AbortController();
	const id = setTimeout(() => controller.abort(), timeout);
	const finalOptions = { ...options, signal: controller.signal };

	return fetch(resource, finalOptions).finally(() => clearTimeout(id));
}

function productMatchesQuery(product, q) {
	if (!q) return true;
	const lower = q.toLowerCase();
		if (product.title && String(product.title).toLowerCase().includes(lower)) return true;
		if (product.body_html && String(product.body_html).toLowerCase().includes(lower)) return true;
		// `product.tags` can be an array or a string depending on the source; handle both
		if (product.tags) {
			if (Array.isArray(product.tags)) {
				const joined = product.tags.map((t) => String(t)).join(' ').toLowerCase();
				if (joined.includes(lower)) return true;
			} else if (String(product.tags).toLowerCase().includes(lower)) {
				return true;
			}
		}
	if (Array.isArray(product.variants)) {
		for (const v of product.variants) {
			if (v.title && v.title.toLowerCase().includes(lower)) return true;
			if (v.sku && v.sku.toLowerCase().includes(lower)) return true;
		}
	}
	return false;
}

/**
 * Fetch products.json and return filtered products.
 *
 * Options:
 * - storeDomain: string (required) e.g. 'https://gymshark.com' or 'https://store.myshopify.com'
 * - query: string (optional) search term; empty returns first items
 * - limit: number (optional) number of items requested from the store endpoint
 * - page: number (optional) the page to request if the store supports it
 * - timeout: ms to wait before aborting the network request
 *
 * Returns: { products: Array, total: number }
 * Throws on network errors or invalid JSON.
 */
export async function searchItems({ storeDomain, query = '', limit = 24, page = 1, timeout = DEFAULT_TIMEOUT } = {}) {
	if (!storeDomain) throw new Error('storeDomain is required');

	const url = buildUrl(storeDomain, { limit, page });

	const res = await timeoutFetch(url, { timeout });
	if (!res.ok) {
		const text = await res.text().catch(() => '');
		throw new Error(`Failed to fetch products.json: ${res.status} ${res.statusText} ${text}`);
	}

	const data = await res.json();
	const products = Array.isArray(data.products) ? data.products : [];

	// If no query, return the first N items (the store may already limit by `limit` param)
	if (!query || !query.trim()) {
		return { products: products.slice(0, limit), total: products.length };
	}

	// Filter client-side for stores that do not support search in this endpoint
	const filtered = products.filter((p) => productMatchesQuery(p, query));
	return { products: filtered.slice(0, limit), total: filtered.length };
}

export default searchItems;

