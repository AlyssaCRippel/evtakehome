import React from 'react';
import ProductCard from './ProductCard';
import Status from './Status';
import './product.css';

export default function ProductList({ products = [], loading = false, error = null, onRetry = null }) {
  const top = products.slice(0, 3);
  const rest = products.slice(3);

  // If there's an error, surface via Status component
  if (error) {
    return (
      <section className="products-root">
        <Status loading={false} error={error} onRetry={onRetry} />
      </section>
    );
  }

  // If loading, show skeleton cards 
  if (loading) {
    const restCount = 6; // show a few placeholders for the rest
    return (
      <section className="products-root">
        <div className="top-products">
          {[0,1,2].map((i) => (
            <ProductCard key={`s-top-${i}`} skeleton fancy />
          ))}
        </div>

        <div className="rest-products">
          {Array.from({ length: restCount }).map((_, i) => (
            <ProductCard key={`s-rest-${i}`} skeleton />
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="products-root">
      {top.length > 0 && (
        <div className="top-products">
          {top.map((p) => (
            <ProductCard key={p.id} product={p} fancy />
          ))}
        </div>
      )}

      {rest.length > 0 && (
        <div className="rest-products">
          {rest.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
      
      {products.length === 0 && (
        <div style={{ padding: 20, color: '#666' }}>No results — try searching for a different term.</div>
      )}
    </section>
  );
}
