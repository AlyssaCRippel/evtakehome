import React from 'react';
import './Status.css';

export default function Status({ loading = false, error = null, onRetry = null }) {
  if (loading) {
    return (
      <div className="status-root">
        <div className="spinner" aria-hidden="true" />
        <div className="status-message">Loading…</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="status-root status-error">
        <div className="status-message">Error: {String(error)}</div>
        {onRetry ? (
          <button className="status-retry" onClick={onRetry}>Retry</button>
        ) : null}
      </div>
    );
  }

  return null;
}
