## Quick run instructions

open folder, naviagte to front_end
npm install
npm start

-- I used a mock instead of a real API call to a LLM so no need to worry about an API Key

## AI usage notes 

Copilot was used to - 

- Generate components (Header, ProductList, ProductCard).
- Design and refine CSS rules for responsive layout, skeletons, and cards.
- Create a Mock LLM request
- Create requests to shopify

Example Prompts - 

Create a header component with a search bar in it, the search barb should appear to the left
When the search button is clicked a request should be sent to shopify with the included search query in order to retrieve items

Create a search function that gets items from https://gymshark.com/products.json, make sure it takes in a search param

Create a card component that can be reused in order to display shop items

AI Notes - 

I used AI to generate basic code very quickly, I knew what I wanted and prompted it in a very basic manor
I evaluated output and made sure any changes that were made were accurate to what I needed.

The only code I wrote for this project was minor tweaks to styling and requests to make sure the requests were reading the incomming json properly

## Simple description of features implemented

- Product list UI: product cards, skeleton loading placeholders, and an error/status component with retry.
- Mock classifier that returns deterministic 'beginner/intermediate/advanced' labels for the top-3 results. (Used for demo; no OpenAI key required.)
- App loads the store listing on mount (first page) and supports searching.

## Improvements

- I could have been more descriptive with some prompt causeing me to have to repromt a few times
- I think i could have inlcuded more info from each item on the cards IE sizing