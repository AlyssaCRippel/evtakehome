import React, { useState, useEffect } from 'react';
import './App.css';
import Header from './components/header';
import ProductList from './components/ProductList';
import searchItems from './requests/search_items';
import mockClassify from './requests/mock_classifier';

const STORE_DOMAIN = 'https://gymshark.com';

function App() {
  const [products, setProducts] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastQuery, setLastQuery] = useState('');

  async function handleSearch(q) {
    setLastQuery(q || '');
    setLoading(true);
    setError(null);
    try {
      const { products: items, total } = await searchItems({
        storeDomain: STORE_DOMAIN,
        query: q,
        limit: 50,
        page: 1,
        timeout: 8000,
      });
      const safeItems = items || [];
      setProducts(safeItems);
      setTotal(total || 0);

      // Send first 3 results to the classification server (if available)
      try {
        const topThree = safeItems.slice(0, 3);
        if (topThree.length === 3) {
            try {
            // Mock classifier for quick prototype (no OpenAI key needed)
            const json = await mockClassify(topThree);
            if (json && Array.isArray(json.classifications)) {
              // Build a map of classifications by product id
              const classMap = new Map(json.classifications.map((c) => [String(c.id), c]));

              // Attach classification data to the top three products
              const topWithClass = topThree.map((p) => ({ ...p, classification: classMap.get(String(p.id)) || null }));

              // Reorder by desired order: beginner, intermediate, advanced
              const order = ['beginner', 'intermediate', 'advanced'];
              const orderedTop = [];
              for (const lvl of order) {
                const found = topWithClass.find((c) => c.classification && c.classification.level && c.classification.level.toLowerCase() === lvl);
                if (found) orderedTop.push(found);
              }

              // If we have all three classifications, combine ordered top with rest and attach null classification to rest
              if (orderedTop.length === 3) {
                const rest = safeItems.slice(3).map((p) => ({ ...p, classification: null }));
                setProducts([...orderedTop, ...rest]);
              } else {
                // If classification didn't return all three as expected, still attach classification where available and keep original order
                const rest = safeItems.slice(3).map((p) => ({ ...p, classification: classMap.get(String(p.id)) || null }));
                const all = topThree.map((p) => ({ ...p, classification: classMap.get(String(p.id)) || null })).concat(rest);
                setProducts(all);
              }
            }
          } catch (err) {
            console.warn('Client classification failed (falling back to original order):', err.message || err);
          }
        }
      } catch (err) {
        console.warn('Classification call failed', err);
      }
    } catch (err) {
      console.error('Search failed', err);
      setError(err.message || String(err));
      setProducts([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }

  // On first load, fetch the first page of products with no query (default store listing)
  useEffect(() => {
    // fire-and-forget initial load; handleSearch manages loading/error state
    handleSearch('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="App">
      <Header onSearch={handleSearch} />
      <main style={{ padding: 20 }}>
        <ProductList
          products={products}
          loading={loading}
          error={error}
          onRetry={() => handleSearch(lastQuery)}
          showTopFancy={Boolean(lastQuery && String(lastQuery).trim())}
        />
      </main>
    </div>
  );
}

export default App;
