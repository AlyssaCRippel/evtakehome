import React, { useState } from 'react';
import '../App.css';
import './header.css';

export default function Header({ onSearch }) {
	const [query, setQuery] = useState('');

	function submit(e) {
		e.preventDefault();
		const trimmed = query.trim();
		if (onSearch) onSearch(trimmed);
	}

	return (
		<header className="site-header">
			<div className="site-brand">
				<h1 className="site-title">My App</h1>
			</div>

			<form className="search-form" onSubmit={submit} role="search" aria-label="Site search">
				<label htmlFor="site-search" className="visually-hidden">Search</label>
				<input
					id="site-search"
					className="search-input"
					type="search"
					value={query}
					onChange={(e) => setQuery(e.target.value)}
					placeholder="Search..."
					aria-label="Search"
				/>
				<button type="submit" className="search-button">Search</button>
			</form>
		</header>
	);
}

Header.defaultProps = {
	onSearch: (q) => console.log('Search:', q),
};

