// Mock classifier that returns an LLM-like JSON response for the top-3 products.
// This is deterministic and safe for local demos (no API key required).

export default async function mockClassify(products) {
  // Simulate small network delay
  await new Promise((res) => setTimeout(res, 250));

  // Ensure we only classify up to 3 products
  const top = (products || []).slice(0, 3);

  // Simple deterministic assignment: first->beginner, second->intermediate, third->advanced
  const levels = ['beginner', 'intermediate', 'advanced'];

  const classifications = top.map((p, i) => ({
    id: p.id,
    level: levels[i] || 'intermediate',
    reason: (() => {
      // Small heuristic to create an LLM-like rationale
      const price = p.variants && p.variants[0] && p.variants[0].price;
      const priceNote = price ? `Practical price point (approx $${price}). ` : '';
      const tagNote = Array.isArray(p.tags) && p.tags.length ? `Tags include ${p.tags.slice(0,3).join(', ')}. ` : '';
      if (i === 0) return `${priceNote}Good choice for beginners. ${tagNote}Simple design and easy to use.`;
      if (i === 1) return `${priceNote}Suitable for intermediate users. ${tagNote}Balanced features and performance.`;
      return `${priceNote}Designed for advanced users. ${tagNote}High performance and technical features.`;
    })(),
  }));

  return { classifications };
}
