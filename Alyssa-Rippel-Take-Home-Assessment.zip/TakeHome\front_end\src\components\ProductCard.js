import React from 'react';
import './product.css';

export default function ProductCard({ product = {}, fancy = false, skeleton = false }) {
  // If skeleton mode is enabled, render placeholder shapes instead of real data
  if (skeleton) {
    return (
      <article className={fancy ? 'product-card fancy skeleton' : 'product-card skeleton'}>
        <div className="product-media">
          <div className="skeleton-box skeleton-image" />
          <div className="classification-badge placeholder" />
        </div>
        <div className="product-body">
          <div className="skeleton-line title" />
          <div className="skeleton-line price" />
          <div className="skeleton-line vendor" />
          <div className="skeleton-line reason short" />
          <div className="skeleton-line reason" />
        </div>
      </article>
    );
  }

  const img = product.images && product.images[0] && product.images[0].src;
  const price = product.variants && product.variants[0] && product.variants[0].price;
  const cls = product.classification || null;

  return (
    <article className={fancy ? 'product-card fancy' : 'product-card'}>
      <div className="product-media">
        {img ? (
          <img src={img} alt={product.title} />
        ) : (
          <div className="product-placeholder">No image</div>
        )}

        {cls && cls.level && (
          <div className={`classification-badge ${cls.level.toLowerCase()}`}>
            {cls.level}
          </div>
        )}
      </div>

      <div className="product-body">
        <h3 className="product-title">{product.title}</h3>
        {price && <div className="product-price">${price}</div>}
        {product.vendor && <div className="product-vendor">{product.vendor}</div>}

        {cls && cls.reason && (
          <div className="classification-reason">{cls.reason}</div>
        )}
      </div>
    </article>
  );
}
